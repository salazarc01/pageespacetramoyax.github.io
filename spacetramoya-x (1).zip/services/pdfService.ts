
import { jsPDF } from 'jspdf';
import { User } from '../types';

export const generateRegistrationPDF = (userData: Partial<User>): string => {
  const doc = new jsPDF();
  
  // Futuristic Header
  doc.setFillColor(30, 27, 75);
  doc.rect(0, 0, 210, 40, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.text('SPACETRAMOYA X', 105, 25, { align: 'center' });
  
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(16);
  doc.text('Solicitud de Inscripción Oficial', 105, 55, { align: 'center' });
  
  doc.setFontSize(12);
  let y = 75;
  const fields = [
    { label: 'Nombre:', value: userData.name },
    { label: 'Apellido:', value: userData.lastName },
    { label: 'País:', value: userData.country },
    { label: 'Teléfono:', value: userData.phone },
    { label: 'Correo:', value: userData.email },
    { label: 'Contraseña elegida:', value: userData.password },
    { label: 'Fecha:', value: new Date().toLocaleString() }
  ];

  fields.forEach(f => {
    doc.setFont('helvetica', 'bold');
    doc.text(f.label, 20, y);
    doc.setFont('helvetica', 'normal');
    doc.text(String(f.value || 'N/A'), 70, y);
    y += 12;
  });

  doc.setFontSize(10);
  doc.text('Al firmar este documento, el usuario acepta los términos y condiciones de SpaceTramoya X.', 20, 180);
  
  return doc.output('datauristring');
};

export const generateMembershipPDF = (user: User): string => {
  const doc = new jsPDF();
  
  // Background
  doc.setFillColor(30, 27, 75);
  doc.rect(0, 0, 210, 297, 'F');
  
  // Header
  doc.setTextColor(192, 132, 252); // Purple
  doc.setFontSize(28);
  doc.text('CERTIFICADO DE MEMBRESÍA', 105, 50, { align: 'center' });
  doc.text('SPACETRAMOYA X', 105, 70, { align: 'center' });
  
  // Body
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  const text = `Yo, ${user.name} ${user.lastName}, declaro ser parte oficial de SpaceTramoya X y me comprometo a mantener la fidelidad, el respeto y la confidencialidad de esta comunidad.`;
  const splitText = doc.splitTextToSize(text, 160);
  doc.text(splitText, 105, 110, { align: 'center' });
  
  // Details
  doc.setFontSize(12);
  doc.text(`ID de Miembro: ${user.id}`, 20, 200);
  doc.text(`País: ${user.country}`, 20, 210);
  doc.text(`Fecha de Activación: ${new Date(user.registeredAt).toLocaleDateString()}`, 20, 220);
  
  // Footer
  doc.setFontSize(10);
  doc.text('Validado por el Sistema Central de SpaceTramoya X', 105, 260, { align: 'center' });
  
  return doc.output('datauristring');
};
