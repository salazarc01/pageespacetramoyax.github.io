
export const ADMIN_CREDENTIALS = {
  username: 'RebbeccaxTramoyaspace0ff1',
  password: 'v9451679',
  securityCode: '090870'
};

export const INITIAL_NOVARES = 10;
export const SUPPORT_EMAIL = 'soportespacetramoyax@gmail.com';

export const OPEN_TIME = { hour: 6, minute: 0 };
export const CLOSE_TIME = { hour: 23, minute: 30 };

export const COUNTRIES = [
  "Argentina", "Bolivia", "Brasil", "Chile", "Colombia", "Costa Rica", "Cuba", 
  "Ecuador", "El Salvador", "España", "Estados Unidos", "Guatemala", "Honduras", 
  "México", "Nicaragua", "Panamá", "Paraguay", "Perú", "Puerto Rico", 
  "República Dominicana", "Uruguay", "Venezuela"
];
